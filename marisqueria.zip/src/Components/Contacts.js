const contacts = [
    {
        namecontact: "Hatsune Miku",
        image: "https://i.scdn.co/image/ab6761610000e5ebba025c8f62612b2ca6bfa375",
        tel: "6149584426", 
        email: "miku@hatsune.com"
    },
    {
        namecontact: "Harry Potter",
        image: "https://img.indiaforums.com/media/640x0/46/1219-ga.jpg",
        tel: "6568775821", 
        email: "potter@harry.com"
    },
    {
        namecontact: "Taylor Swift",
        image: "https://i.ytimg.com/vi/M98xyWVzZtY/sddefault.jpg",
        tel: "5856872269", 
        email: "swift@taylor.com"
    },
    {
        namecontact: "Ed Sheeran",
        image: "http://t3.gstatic.com/images?q=tbn:ANd9GcRya1QzElioKuhn6COipS8U5kzqtbSmsOYeQzAnB7PURbnKX4UodWsgnL8l16EVa0dCimThRg",
        tel: "--------------", 
        email: "sheeran@ed.com"
    },
    {
        namecontact: "Taylor Swift",
        image: "https://i.ytimg.com/vi/M98xyWVzZtY/sddefault.jpg",
        tel: "5856872269", 
        email: "swift@taylor.com"
    },
    {
        namecontact: "Taylor Swift",
        image: "https://i.ytimg.com/vi/M98xyWVzZtY/sddefault.jpg",
        tel: "5856872269", 
        email: "swift@taylor.com"
    },
    {
        namecontact: "Taylor Swift",
        image: "https://i.ytimg.com/vi/M98xyWVzZtY/sddefault.jpg",
        tel: "5856872269", 
        email: "swift@taylor.com"
    },
    {
        namecontact: "Taylor Swift",
        image: "https://i.ytimg.com/vi/M98xyWVzZtY/sddefault.jpg",
        tel: "5856872269", 
        email: "swift@taylor.com"
    },
    {
        namecontact: "Taylor Swift",
        image: "https://i.ytimg.com/vi/M98xyWVzZtY/sddefault.jpg",
        tel: "5856872269", 
        email: "swift@taylor.com"
    },
    {
        namecontact: "Taylor Swift",
        image: "https://i.ytimg.com/vi/M98xyWVzZtY/sddefault.jpg",
        tel: "5856872269", 
        email: "swift@taylor.com"
    }
];

export default contacts;